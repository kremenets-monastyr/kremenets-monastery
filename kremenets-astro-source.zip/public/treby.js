const CROSS = `<svg viewBox="0 0 900 900" fill="currentColor" preserveAspectRatio="xMidYMid meet" style="width:100%;height:100%"><g transform="translate(0,900) scale(0.1,-0.1)"><path d="M4070 8984 c-438 -47 -946 -174 -1298 -325 -153 -65 -518 -254 -652
-337 -246 -152 -635 -467 -880 -712 -265 -266 -607 -757 -775 -1113 -78 -167
-165 -365 -187 -427 -152 -433 -233 -787 -268 -1165 -13 -143 -13 -708 0 -833
28 -266 90 -577 155 -782 18 -58 50 -159 70 -225 40 -132 200 -507 302 -708
160 -316 482 -736 828 -1082 689 -690 1703 -1161 2700 -1255 193 -18 540 -23
730 -11 558 36 1173 200 1650 438 328 165 498 263 650 377 250 188 439 351
642 557 270 274 425 481 665 884 114 191 149 260 193 374 18 47 57 145 88 217
118 280 224 665 272 989 44 294 59 735 35 1020 -59 696 -276 1360 -646 1972
-450 745 -1064 1303 -1893 1717 -436 219 -986 375 -1519 431 -174 19 -686 18
-862 -1z m765 -454 c819 -71 1591 -382 2220 -895 292 -238 655 -640 850 -944
84 -131 272 -500 336 -660 86 -218 112 -295 170 -509 103 -379 123 -544 122
-1022 -2 -495 -24 -675 -134 -1061 -204 -717 -515 -1256 -1014 -1754 -447
-447 -845 -716 -1375 -930 -352 -142 -689 -229 -1080 -277 -139 -17 -706 -17
-855 1 -307 35 -585 96 -849 183 -1151 383 -2097 1298 -2525 2442 -242 645
-309 1344 -195 2046 119 731 442 1422 929 1987 704 818 1677 1304 2790 1396
97 8 501 6 610 -3z M4033 8121 c-50 -13 -63 -29 -63 -75 0 -29 12 -63 40 -113
71 -132 71 -132 80 -598 11 -536 16 -2212 8 -2221 -11 -10 -79 16 -128 50 -25
17 -81 65 -125 106 -44 42 -133 120 -197 174 -65 54 -178 155 -252 226 -74 71
-228 209 -343 306 -114 98 -266 233 -338 300 -71 67 -195 178 -275 246 -170
146 -312 292 -430 443 -115 147 -133 165 -167 165 -41 0 -65 -20 -135 -113
-34 -45 -115 -146 -180 -225 -65 -79 -118 -151 -118 -160 0 -50 87 -123 264
-223 60 -35 149 -97 198 -138 49 -42 123 -104 164 -137 41 -34 139 -118 217
-187 78 -69 207 -181 286 -249 566 -483 737 -629 891 -760 418 -354 442 -380
448 -481 4 -61 3 -64 -37 -114 -22 -28 -81 -87 -130 -130 -49 -43 -166 -148
-258 -233 -93 -85 -391 -353 -663 -595 -272 -242 -558 -502 -636 -577 -210
-203 -280 -249 -505 -337 -117 -46 -192 -89 -209 -121 -23 -43 16 -107 165
-275 53 -59 123 -147 155 -194 92 -133 122 -161 176 -161 53 0 94 45 165 183
73 140 106 176 410 450 96 86 225 204 287 262 62 57 156 140 210 183 53 44
162 142 242 218 80 77 208 195 285 264 77 68 187 169 246 224 196 188 277 255
307 256 10 0 12 -225 10 -1147 l-3 -1148 -29 -85 c-15 -46 -50 -141 -78 -210
-56 -144 -58 -174 -11 -206 30 -20 35 -21 107 -8 87 15 296 35 305 30 3 -2 73
-6 155 -7 145 -4 149 -3 167 20 23 28 21 38 -33 181 -86 229 -79 121 -90 1498
-6 673 -7 1226 -4 1229 3 3 15 2 25 -3 32 -15 644 -541 1226 -1054 160 -141
372 -327 472 -414 196 -169 222 -200 371 -426 115 -175 154 -226 193 -245 25
-14 33 -14 57 -1 41 21 417 417 441 464 30 59 28 122 -5 161 -20 24 -46 37
-112 57 -116 35 -214 81 -287 136 -33 24 -149 125 -259 224 -206 186 -233 209
-405 351 -57 47 -151 131 -210 187 -58 56 -189 171 -291 256 -101 85 -223 191
-271 236 -47 44 -158 141 -245 215 -87 73 -210 183 -272 244 l-112 110 0 64
c0 57 4 68 35 112 42 57 154 160 401 370 340 289 578 494 739 634 88 77 207
180 265 229 58 50 155 133 215 186 61 53 155 133 210 177 55 44 146 121 201
169 73 64 133 106 213 148 139 74 201 125 201 168 0 25 -19 49 -119 146 -87
85 -132 139 -167 197 -53 90 -100 145 -124 145 -24 0 -68 -52 -159 -187 -67
-100 -110 -149 -246 -281 -90 -88 -213 -202 -272 -253 -59 -51 -155 -138 -213
-193 -58 -54 -175 -157 -260 -227 -85 -70 -225 -194 -310 -275 -85 -80 -200
-183 -255 -228 -55 -44 -189 -165 -297 -268 -169 -160 -277 -254 -325 -281 -6
-4 -18 -4 -27 -1 -14 5 -16 37 -16 258 0 232 11 420 25 457 5 13 36 17 173 22
376 14 577 86 840 300 164 133 297 341 382 596 152 454 57 843 -289 1192 -166
167 -304 253 -508 316 l-88 27 -530 2 c-291 2 -545 -1 -562 -5z m984 -442
c188 -25 309 -84 434 -209 69 -69 95 -103 130 -175 l44 -88 3 -215 c4 -284
-15 -370 -115 -524 -82 -126 -201 -214 -364 -269 -91 -32 -101 -33 -285 -37
-136 -3 -198 -1 -214 8 -50 27 -50 30 -50 755 0 744 -2 717 62 748 40 20 232
23 355 6z M1808 5208 c-9 -8 -18 -35 -21 -63 -5 -44 -11 -55 -64 -105 -91 -87
-122 -130 -259 -365 -208 -356 -269 -522 -262 -709 3 -87 8 -110 34 -166 34
-72 94 -138 152 -166 58 -29 182 -31 261 -4 78 26 155 74 199 124 18 20 60 84
93 141 34 58 65 105 70 105 13 0 33 -45 69 -155 39 -123 51 -146 90 -179 28
-23 40 -26 113 -26 66 0 92 5 135 25 87 41 88 30 -26 376 -121 365 -233 759
-268 940 -44 232 -50 239 -194 239 -70 0 -112 -4 -122 -12z m40 -530 c38 -77
65 -227 60 -344 -6 -133 -37 -202 -136 -303 -68 -69 -71 -71 -119 -71 -92 0
-133 65 -133 208 0 127 98 377 189 484 37 43 89 80 106 75 6 -2 20 -24 33 -49z
M6300 5152 c-64 -21 -190 -178 -259 -322 l-46 -95 0 -195 0 -195 38 -108 c44
-130 123 -288 172 -344 64 -75 184 -139 306 -163 86 -17 217 -15 268 4 69 25
146 90 219 182 36 46 69 84 73 84 4 0 17 -15 28 -33 28 -46 127 -138 181 -169
104 -60 263 -76 375 -38 163 56 289 200 355 407 43 134 53 216 47 388 -7 215
-42 320 -138 414 -60 60 -124 88 -166 74 -26 -9 -28 -13 -25 -59 2 -27 12 -78
22 -114 21 -72 43 -258 42 -361 0 -119 -31 -299 -60 -349 -59 -102 -174 -180
-265 -180 -51 0 -129 45 -189 108 -101 106 -115 156 -125 451 l-6 194 -30 34
c-59 67 -156 34 -207 -72 -30 -63 -28 -124 6 -183 55 -96 64 -117 64 -157 -1
-180 -179 -414 -318 -415 -18 0 -50 9 -71 20 -137 70 -321 437 -338 676 -7 95
6 182 47 316 38 124 47 180 29 195 -8 5 -21 8 -29 5z"/></g></svg>`;
['sc','sc2'].forEach(id=>{const e=document.getElementById(id);if(e)e.innerHTML=CROSS;});
document.querySelectorAll('.choice .cr').forEach(e=>e.innerHTML=CROSS);

/* Ціни — точно з прайсу обителі (Требы.pdf). Усе «за одне ім'я». */
const TREBY=[
 {n:1, grp:'Проскомідія',      t:'1 день · заказна Літургія', s:'З вийняттям часточок',  price:2,    unit:'name',     live:1, dead:1},
 {n:2, grp:'Проскомідія',      t:'40 днів · сорокоуст',       s:'З вийняттям часточок',  price:50,   unit:'name',     live:1, dead:1},
 {n:3, grp:'Просте поминання', t:'1 місяць',  s:'Поминання на Літургії', price:20,   unit:'name',     live:1, dead:1},
 {n:4, grp:'Просте поминання', t:'6 місяців', s:'Поминання на Літургії', price:120,  unit:'name',     live:1, dead:1},
 {n:5, grp:'Просте поминання', t:'1 рік',     s:'Поминання на Літургії', price:240,  unit:'name',     live:1, dead:1},
 {n:6, grp:'Просте поминання', t:'5 років',   s:'Поминання на Літургії', price:1200, unit:'name',     live:1, dead:1},
 {n:7, grp:'Просте поминання', t:'За запискою', s:'На пожертву',         price:0,    unit:'donation', live:1, dead:1},
 {n:8, grp:'Неусипна псалтир', t:'1 місяць',  s:'На Неусипній Псалтирі', price:20,   unit:'name',     live:1, dead:1},
 {n:9, grp:'Неусипна псалтир', t:'6 місяців', s:'На Неусипній Псалтирі', price:120,  unit:'name',     live:1, dead:1},
 {n:10,grp:'Неусипна псалтир', t:'1 рік',     s:'На Неусипній Псалтирі', price:240,  unit:'name',     live:1, dead:1},
 {n:11,grp:'40 акафістів',     t:'Б. М. «Скорбяща»',          s:'40 акафістів', price:30, unit:'name', live:1, dead:0},
 {n:12,grp:'40 акафістів',     t:'Свт. Миколаю Чудотворцю',   s:'40 акафістів', price:30, unit:'name', live:1, dead:0},
 {n:13,grp:'40 акафістів',     t:'Вмч. Пантелеймону',         s:'40 акафістів', price:30, unit:'name', live:1, dead:0},
 {n:14,grp:'40 акафістів',     t:'«Неупиваєма Чаша» · 1 рік', s:'40 акафістів', price:60, unit:'name', live:1, dead:0},
 {n:15,grp:'40 акафістів',     t:'«Всецариця» · 1 рік',       s:'40 акафістів', price:60, unit:'name', live:1, dead:0},
 {n:16,grp:'40 акафістів',     t:'Подячний молебень',         s:'За одне ім\u2019я', price:2, unit:'name', live:1, dead:0},
 {n:17,grp:'Панахида',         t:'Панахида',                  s:'Заупокійне поминання — на пожертву', price:0, unit:'donation', live:0, dead:1},
];
const fmt=v=>v.toLocaleString('uk-UA')+' грн';
const TYPE={living:{ttl:"За здоров'я",cls:'living'},dead:{ttl:"За упокій",cls:'dead'}};
let sheets=[],uid=0;

function addSheet(type){uid++;sheets.push({id:uid,type,treba:null,names:['']});render();
  setTimeout(()=>document.getElementById('sheet-'+uid)?.scrollIntoView({behavior:'smooth',block:'center'}),60);}
function orderFromList(type,n){uid++;sheets.push({id:uid,type,treba:n,names:['']});render();
  setTimeout(()=>document.getElementById('sheet-'+uid)?.scrollIntoView({behavior:'smooth',block:'center'}),80);}
function goToSheet(id){const el=document.getElementById('sheet-'+id),s=sheets.find(x=>x.id===id);if(!el)return;el.scrollIntoView({behavior:'smooth',block:'center'});el.classList.remove('flash');void el.offsetWidth;el.classList.add('flash');setTimeout(()=>{let t;if(s&&s.treba==null){t=el.querySelector('select');}else{const inps=[...el.querySelectorAll('.nrow input')];t=inps.find(i=>!i.value.trim())||inps[inps.length-1];}t&&t.focus({preventScroll:true});},380);}
function cardClick(e,id){if(e.target.closest('input,select,button,textarea,a'))return;const root=document.getElementById('sheet-'+id),s=sheets.find(x=>x.id===id);if(!root||!s)return;if(s.treba==null){const sel=root.querySelector('select');sel&&sel.focus();}else{const inps=[...root.querySelectorAll('.nrow input')],t=inps.find(i=>!i.value.trim())||inps[inps.length-1];t&&t.focus();}}
function removeSheet(id){sheets=sheets.filter(s=>s.id!==id);render();}
function setTreba(id,n){sheets.find(x=>x.id===id).treba=+n;render();}
function setName(id,i,v){const s=sheets.find(x=>x.id===id);s.names[i]=v;updateSheetSum(s);computeTotals();}
function updateSheetSum(s){const sm=sheetSum(s),txt=sm==null?'—':sm.kind==='donation'?'пожертва':fmt(sm.v);const el=document.querySelector('#sheet-'+s.id+' .sum');if(el)el.textContent=txt;}
function addName(id){sheets.find(x=>x.id===id).names.push('');render();}
function delName(id,i){const s=sheets.find(x=>x.id===id);s.names.splice(i,1);if(!s.names.length)s.names=[''];render();}

function sheetSum(s){
  if(s.treba==null)return null;
  const tr=TREBY.find(t=>t.n===s.treba),cnt=s.names.filter(n=>n.trim()).length;
  if(tr.unit==='donation')return{kind:'donation'};
  if(tr.unit==='fixed')return{kind:'sum',v:tr.price};
  if(tr.unit==='list')return{kind:'sum',v:cnt?tr.price:0};
  return{kind:'sum',v:tr.price*cnt};
}

function render(){
  const box=document.getElementById('sheets');box.innerHTML='';
  sheets.forEach(s=>{
    const opts=TREBY.filter(t=>s.type==='living'?t.live:t.dead);
    let lg=null,optHtml=`<option value="" disabled ${s.treba==null?'selected':''}>— оберіть требу —</option>`;
    opts.forEach(t=>{if(t.grp!==lg){if(lg!==null)optHtml+='</optgroup>';optHtml+=`<optgroup label="${t.grp}">`;lg=t.grp;}
      optHtml+=`<option value="${t.n}" ${s.treba===t.n?'selected':''}>${t.t}</option>`;});
    if(lg!==null)optHtml+='</optgroup>';
    const tr=s.treba!=null?TREBY.find(t=>t.n===s.treba):null;
    let meta='';
    if(tr){const p=tr.unit==='donation'?'на пожертву':tr.unit==='list'?fmt(tr.price)+' за список':tr.unit==='fixed'?fmt(tr.price):fmt(tr.price)+' за одне ім\u2019я';meta=`${tr.grp} · ${p}`;}
    const sm=sheetSum(s),sumTxt=sm==null?'—':sm.kind==='donation'?'пожертва':fmt(sm.v);
    const isL=s.type==='living';
    const ph0=isL?'напр. Іоанна, болящого':'напр. Іоанна, новопреставленого';
    const names=s.names.map((nm,i)=>`<div class="nrow"><span class="nnum">${i+1}</span><input value="${nm.replace(/"/g,'&quot;')}" placeholder="${i===0?ph0:'імʼя з приписками'}" oninput="setName(${s.id},${i},this.value)"><button class="del" onclick="delName(${s.id},${i})">видалити</button></div>`).join('');
    const el=document.createElement('div');el.className='zap '+TYPE[s.type].cls;el.id='sheet-'+s.id;el.setAttribute('onclick','cardClick(event,'+s.id+')');
    el.innerHTML=`<button class="x" onclick="removeSheet(${s.id})">видалити</button>
      <div class="zhead"><div class="cr">${CROSS}</div><div class="ttl">${TYPE[s.type].ttl}</div></div>
      <div class="zrule"></div>
      <div class="treba"><label>Треба</label><select onchange="setTreba(${s.id},this.value)">${optHtml}</select><div class="meta">${meta}</div></div>
      <div class="names">${names}<button class="addname" onclick="addName(${s.id})">Додати імʼя</button><div class="znote">${isL?'За потреби — примітка: болящого, воїна, подорожуючого':'За потреби — примітка: новопреставленого, приснопамʼятного, воїна'}</div></div>
      <div class="zfoot"><span class="lbl">Сума по записці</span><span class="sum">${sumTxt}</span></div>`;
    box.appendChild(el);
  });
  if(sheets.length){
    const add=document.createElement('div');add.className='addcard';
    add.innerHTML=`<div class="plus"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:22px;height:22px"><path d="M5 4h11l3 3v13H5z"/><path d="M8 9h8M8 13h8M8 17h5"/></svg></div><div class="ac-q">Додати ще одну записку</div>
      <div class="ac-btns">
        <button class="living" onclick="addSheet('living')">За здоров'я</button>
        <button class="dead" onclick="addSheet('dead')">За упокій</button>
      </div>`;
    box.appendChild(add);
  }
  document.getElementById('stil2').style.display=sheets.length?'block':'none';
  document.getElementById('railstil').style.display=sheets.length?'flex':'none';
  document.getElementById('checkout').style.display=sheets.length?'block':'none';
  computeTotals();
}

function computeTotals(){
  const sum=document.getElementById('summary');if(!sum)return;sum.innerHTML='';
  let grand=0,hasDon=false;
  sheets.forEach((s,idx)=>{
    const tr=s.treba!=null?TREBY.find(t=>t.n===s.treba):null,sm=sheetSum(s);let v='—';
    if(sm){if(sm.kind==='donation'){v='пожертва';hasDon=true;}else{v=fmt(sm.v);grand+=sm.v;}}
    const row=document.createElement('div');row.className='crow link';
    row.setAttribute('onclick','goToSheet('+s.id+')');
    row.innerHTML=`<span class="nm">${idx+1}. ${TYPE[s.type].ttl}${tr?' — '+tr.t:''}</span><span class="v">${v}</span><button class="crow-x" title="Видалити записку" onclick="event.stopPropagation();removeSheet(${s.id})">✕</button>`;
    sum.appendChild(row);
  });
  document.getElementById('grand').textContent=fmt(grand)+(hasDon?' + пожертва':'');
}

/* Список треб — групи у порядку прайсу */
(function(){
  const order=[],map={};
  TREBY.forEach(t=>{if(!map[t.grp]){map[t.grp]=[];order.push(t.grp);}map[t.grp].push(t);});
  const card=t=>{
    const p=t.unit==='donation'?'пожертва':t.unit==='list'?fmt(t.price)+' / список':t.unit==='fixed'?fmt(t.price):fmt(t.price)+' / ім\u2019я';
    const types=[t.live&&'living',t.dead&&'dead'].filter(Boolean),single=types.length===1,lbl={living:"За здоров'я",dead:"За упокій"};
    const btns=types.map(tp=>`<button class="tbtn ${tp}"${single?'':` onclick="orderFromList('${tp}',${t.n})"`}>${lbl[tp]}</button>`).join('');
    const open=single?` onclick="orderFromList('${types[0]}',${t.n})" style="cursor:pointer"`:'';
    return `<div class="tcard"${open}><div class="tc-head"><span class="tc-num">№${t.n}</span><span class="tc-price">${p}</span></div><div class="tc-title">${t.t}</div><div class="tc-sub">${t.s}</div><div class="tc-acts">${btns}</div></div>`;
  };
  document.getElementById('trebaList').innerHTML=order.map(g=>{
    const cards=map[g].map(card).join('');
    return `<div class="tgroup"><h3 class="gh">${g}</h3><div class="tgrid">${cards}</div></div>`;
  }).join('');
})();

function buildPayload(){
  const filled=sheets.filter(s=>s.treba!=null&&s.names.some(n=>n.trim()));
  let total=0,hasDon=false;
  const out=filled.map(s=>{const tr=TREBY.find(t=>t.n===s.treba),sm=sheetSum(s);let sum=null;
    if(sm.kind==='donation')hasDon=true;else{total+=sm.v;sum=sm.v;}
    return{type:s.type,trebaN:tr.n,trebaGroup:tr.grp,trebaTitle:tr.t,unit:tr.unit,names:s.names.filter(n=>n.trim()),sum};});
  var hpEl=document.getElementById('hp');
  return{name:(document.getElementById('uname')||{}).value?document.getElementById('uname').value.trim():'',phone:document.getElementById('phone').value.trim(),hp:hpEl?hpEl.value:'',total,hasDonation:hasDon,sheets:out};
}
function toast(t){var e=document.getElementById('toast');if(!e)return;e.textContent=t;e.classList.add('show');setTimeout(function(){e.classList.remove('show');},4500);}
function resetAll(){sheets=[];uid=0;render();['phone','uname'].forEach(function(id){var e=document.getElementById(id);if(e)e.value='';});}
function copyTxt(t,el){try{navigator.clipboard.writeText(t).then(function(){var o=el.getAttribute('data-lbl')||el.textContent;el.setAttribute('data-lbl',o);el.textContent='Скопійовано \u2713';setTimeout(function(){el.textContent=o;},1500);});}catch(e){}}
function showConfirm(code){
  var co=document.getElementById('checkout'), sh=document.getElementById('sheets'); if(sh)sh.innerHTML='';
  co.style.display='block';
  var link=location.origin+'/z/'+code;
  co.innerHTML='<div class="confirm">'
    +'<div class="cf-ic">\u2713</div>'
    +'<h3>Записку прийнято</h3>'
    +'<div class="cf-code">Ваш номер запису<br><b>'+code+'</b></div>'
    +'<button class="cta2 cf-copy" data-copy="'+code+'">Скопіювати номер</button>'
    +'<div class="cf-req"><div class="cf-req-t">Реквізити для пожертви</div><div class="cf-req-b" id="cfReqBody">Завантаження\u2026</div></div>'
    +'<p class="cf-note">У коментарі до платежу вкажіть <b>номер</b> або ваше <b>ім\u2019я та телефон</b>. Оплатити можна будь-коли протягом 7 днів.</p>'
    +'<div class="cf-keep">Сторінка для оплати (збережіть посилання):<br><a href="'+link+'" target="_blank" rel="noopener">'+link+'</a></div>'
    +'<button class="cta" onclick="location.reload()">Подати ще одну записку</button>'
    +'</div>';
  co.querySelectorAll('[data-copy]').forEach(function(b){b.addEventListener('click',function(){copyTxt(b.getAttribute('data-copy'),b);});});
  fetch('/api/requisites').then(function(r){return r.json();}).then(function(d){
    var body=document.getElementById('cfReqBody'); if(!body)return;
    if(d&&d.ok&&d.text){
      var safe=d.text.replace(/[<>&]/g,function(c){return c==='<'?'&lt;':c==='>'?'&gt;':'&amp;';});
      body.innerHTML='<pre class="cf-req-pre">'+safe+'</pre><button class="cta2 cf-copy" id="cfReqCopy">Скопіювати реквізити</button>';
      var rc=document.getElementById('cfReqCopy'); rc.addEventListener('click',function(){copyTxt(d.text,rc);});
    } else { body.innerHTML='<span class="cf-req-fallback">Реквізити надасть обитель — зверніться до контактів і назвіть номер запису.</span>'; }
  }).catch(function(){var body=document.getElementById('cfReqBody'); if(body)body.innerHTML='<span class="cf-req-fallback">Реквізити надасть обитель — зверніться до контактів.</span>';});
}
async function sendOrder(){
  var name=(document.getElementById('uname')||{value:''}).value.trim(),phone=document.getElementById('phone').value.trim(),box=document.getElementById('formmsg'),btn=document.querySelector('.send');
  if(!sheets.some(function(s){return s.treba!=null&&s.names.some(function(n){return n.trim();});})){box.textContent='Заповніть хоча б одну записку';box.className='formmsg err';return;}
  if(!name){box.textContent='Вкажіть ваше ім’я';box.className='formmsg err';return;}
  if(!phone){box.textContent='Вкажіть контактний номер телефону';box.className='formmsg err';return;}
  box.textContent='Надсилаємо…';box.className='formmsg';if(btn)btn.disabled=true;
  try{
    var r=await fetch('/api/send-treba',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(buildPayload())});
    var d={};try{d=await r.json();}catch(e){}
    if(r.ok&&d.ok){toast('Записку прийнято ✓');sheets=[];uid=0;showConfirm(d.code);}
    else{box.textContent=(d&&d.error)?d.error:'Не вдалося надіслати. Спробуйте ще раз або зателефонуйте до обителі.';box.className='formmsg err';}
  }catch(e){box.textContent='Помилка зʼєднання. Перевірте інтернет і спробуйте ще раз.';box.className='formmsg err';}
  finally{if(btn)btn.disabled=false;}
}
